.. Markov Clustering documentation master file, created by
   sphinx-quickstart on Sat Sep 30 18:06:08 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Markov Clustering for Python
============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
